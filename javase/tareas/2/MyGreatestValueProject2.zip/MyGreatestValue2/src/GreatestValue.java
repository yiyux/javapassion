/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yiyo
 */
public class GreatestValue {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // TODO code application logic here
        int num1 = 10;
        int num2 = 23;
        int num3 = 5;
        int min = 0;

        min = (num1 < num2)?num1:num2;
        min = (min < num3)?min:num3;

        System.out.println("Number 1: "+ num1);
        System.out.println("Number 2: "+ num2);
        System.out.println("number 3: "+ num3);
        System.out.println("The min values is: " + min);
        System.out.println((min <10)?"The smallest value is less than 10":"the smallest value is greater or equal to10!");

    }

}
