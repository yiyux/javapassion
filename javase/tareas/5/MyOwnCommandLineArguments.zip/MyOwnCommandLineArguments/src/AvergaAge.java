/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yiyo
 */
public class AvergaAge {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        if(args.length == 0 || args.length > 6 || args.length < 6){
            System.out.println("Incorrects arguments. Now exit...");
            System.exit(0);
        }
            

        int int1 = Integer.parseInt(args[1]);
        int int2 = Integer.parseInt(args[3]);
        int int3 = Integer.parseInt(args[5]);
        int avg = (int1 + int2 +int3)/3;
        System.out.println("Average Age = " + avg);
    }

}
