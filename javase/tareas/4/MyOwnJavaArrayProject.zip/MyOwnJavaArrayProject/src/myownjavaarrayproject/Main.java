/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package myownjavaarrayproject;

import javax.swing.JOptionPane;

/**
 *
 * @author yiyo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String person[] = new String[3];
        String name = null;
        String largestname = null;
        int x;

        for(x = 0; x < 3 ; x++){
            name = (String)JOptionPane.showInputDialog("Input the first and the second name ");
            String []firstname = name.split(" ");
            person[x] = firstname[0];
            if(x != 0){
                if(person[x].length() > person[x-1].length()){
                    largestname = person[x];
                }
            } else {
                largestname = person[x];
            }
            System.out.println(person[x]);
        }
        System.out.println(largestname + " is the largest name of the list");
    }

}
