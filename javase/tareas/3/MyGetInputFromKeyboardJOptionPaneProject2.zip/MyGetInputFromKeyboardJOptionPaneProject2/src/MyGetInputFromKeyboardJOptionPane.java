/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JOptionPane;

/**
 *
 * @author yiyo
 */
public class MyGetInputFromKeyboardJOptionPane {

    public MyGetInputFromKeyboardJOptionPane(){

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String name = "";
        name = JOptionPane.showInputDialog("Please enter your name");
        String msg = "Hello " + name + "!";
        JOptionPane.showMessageDialog(null, msg);
        String age;
        age = JOptionPane.showInputDialog("Please enter your age");
        try{
            int ageint = Integer.parseInt(age);
            if(ageint > 100){
                msg = "Hello " + name + "! You are old.";
            } else {
                msg = "Hello " + name + "! You are young.";
            }
            
        } catch (NumberFormatException e){
            msg = "Error reading your age!!!";
        }
        JOptionPane.showMessageDialog(null, msg);
    }

}