/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yiyo
 */
public class NewName {

    static String new_name;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        if(args.length == 0 || args.length < 3 || args.length > 6)
            System.exit(0);
        generateNewName(args);
        for(int counter = 0; counter < args.length; counter++){
             System.out.println(args[counter]);
        }
        System.out.println(new_name);
    }

    public static void generateNewName(String[] names){
        new_name = "";
        for(int counter = 0; counter < names.length; counter++){
             new_name = new_name + names[counter].charAt(1);
        }
    }

}
